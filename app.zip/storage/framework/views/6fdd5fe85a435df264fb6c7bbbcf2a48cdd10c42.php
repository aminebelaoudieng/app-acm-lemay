<?php echo e($slot); ?>

<?php /**PATH /home/lemaycon/app.lemayconsulting.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>